import os,json,sys,logging
sys.path.append("./share")
sys.path.append("./common")
import pandas as pd
import json
from tqdm import tqdm
from IoTCommon import CIoTCommon
from IoTTotalFeature import CIoTTotalFeature
from Config import g_data_root
g_sample_root = "%ssample"%g_data_root

class CIoTSample:
    
    def __init__(self):
        self.m_index = self.get_index()
        
    def get_index(self):
        all_data =[]
        for fi in CIoTCommon.get_json_files(g_sample_root):
            fi = fi.replace("\\","/")
            temp = fi.split("/")
            attackType,trafficType,segment,protocol = temp[-4],temp[-3],temp[-2],temp[-1].split(".json")[0]
            protocol = protocol.replace("-",":")
            tmp = {}
            tmp['attackType'] = attackType
            tmp['trafficType'] = trafficType
            tmp['segment'] = segment
            tmp['protocol'] = protocol
            tmp['file'] = fi
            all_data.append(tmp)
        return pd.DataFrame(all_data)

    def get_attack_type(self):
        df_tmp = self.m_index[self.m_index['attackType'] == 'Attack']
        return df_tmp['trafficType'].unique().tolist()

    def get_sensor_type(self):
        df_tmp = self.m_index[self.m_index['attackType'] == 'Normal']
        return df_tmp['trafficType'].unique().tolist()
    
    def get_attack_protocol(self,trafficType):
        mask = (self.m_index['attackType']=='Attack') & (self.m_index['trafficType']==trafficType)
        df_tmp = self.m_index[mask]
        return df_tmp['protocol'].unique().tolist()
    
    def get_attack_sample(self,trafficType = None,protocol = None):
        if trafficType == None:
            if protocol == None:
                mask = (self.m_index['attackType']=='Attack')
            else:
                mask = (self.m_index['attackType']=='Attack') & (self.m_index['protocol']==protocol)
        else:
            if protocol == None:
                mask = (self.m_index['attackType']=='Attack') & (self.m_index['trafficType']==trafficType)
            else:
                mask = (self.m_index['attackType']=='Attack') & (self.m_index['trafficType']==trafficType) & (self.m_index['protocol']==protocol)
        
        df_sample = pd.DataFrame()
        
        if self.m_index[mask].shape[0] <= 0:
            print("No Attack sample found trafficType=%r,protocol=%r"%(trafficType,protocol))
            return df_sample
        
        for file in self.m_index[mask]['file'].tolist():
            df_tmp = pd.read_json(file)
            df_sample = pd.concat([df_sample,df_tmp],ignore_index=False)
        
        return df_sample.sort_values(by='frame.time_utc').reset_index(drop=True)

    def get_sensor_protocol(self,trafficType):
        mask = (self.m_index['attackType']=='Normal') & (self.m_index['trafficType']==trafficType)
        df_tmp = self.m_index[mask]
        return df_tmp['protocol'].unique().tolist()
    
    def get_sensor_sample(self,trafficType=None,protocol = None):
        if trafficType == None:
            if protocol == None:
                mask = (self.m_index['attackType']=='Normal')
            else:
                mask = (self.m_index['attackType']=='Normal') & (self.m_index['protocol']==protocol)
        else:
            if protocol == None:
                mask = (self.m_index['attackType']=='Normal') & (self.m_index['trafficType']==trafficType)
            else:
                mask = (self.m_index['attackType']=='Normal') & (self.m_index['trafficType']==trafficType) & (self.m_index['protocol']==protocol)
        
        df_sample = pd.DataFrame()
        
        if self.m_index[mask].shape[0] <= 0:
            print("No Normal sample found trafficType=%r,protocol=%r"%(trafficType,protocol))
            return df_sample
            
        for file in self.m_index[mask]['file'].tolist():
            df_tmp = pd.read_json(file)
            df_sample = pd.concat([df_sample,df_tmp],ignore_index=False)
        
        return df_sample.sort_values(by='frame.time_utc').reset_index(drop=True)

def main():
    test = CIoTSample()
    trafficType = "Backdoor_attack"
    protocol = "eth:ethertype:ip:tcp:data"
    df_test = test.get_attack_sample(trafficType=trafficType,protocol=protocol)
    print(df_test)
    
if __name__ == "__main__":
    main()