g_data_root = "./IIoTset/"
